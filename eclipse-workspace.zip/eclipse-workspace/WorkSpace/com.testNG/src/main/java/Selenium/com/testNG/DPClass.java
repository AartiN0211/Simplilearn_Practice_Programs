package Selenium.com.testNG;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DPClass {

  @DataProvider
  public String[] dp1() {
    String[] data= new String[] { "a","b"};
    return data;
  }
}

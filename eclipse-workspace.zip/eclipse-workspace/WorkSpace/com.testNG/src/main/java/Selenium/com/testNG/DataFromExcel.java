package Selenium.com.testNG;

import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;

import org.testng.annotations.DataProvider;

public class DataFromExcel {
@Test
  @DataProvider
//  public Object[][] dp1() {
  public void F1() {
   File file=new File("C:\\Users\\Aarti\\eclipse-workspace\\com.testNG\\DATA.xlsx");
  System.out.println(file.exists());
   //   FileInputStream fis=new 

}}

package Selenium.com.testNG;

import org.testng.annotations.Test;

public class DPInDifferentClass {
  @Test(dataProvider = "dp1", dataProviderClass = DPClass.class)
  public void Method(String s) {
	  System.out.println(s);
  }
}

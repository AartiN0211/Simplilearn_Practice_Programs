package Selenium.com.testNG;
import org.testng.Assert;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AmazonSearchFunctionality {
 
	  WebDriver driver=null;
	
	  @BeforeMethod
	   public void LaunchBrowser( @Optional("chrome") String BN)  {
		  switch(BN)
		  {
			 
		  case "chrome":
		  System.setProperty("WebDriver.chrome.driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
	       driver=new ChromeDriver();
	       driver.get("https://www.facebook.com/login/");
	       break;
		    default:
		    	System.out.println("NO OS is there");
			  
	  }}

		
	
	    
		@Test(priority=1)
		public void Login()
		{ 
			
		       driver.findElement(By.id("email")).sendKeys("8421696801",Keys.ENTER);

		       //Title Assertion
		       String ExpectedTitle=driver.getTitle();
		       String actual= "Log in to Facebook" ; 
		       assertEquals(actual,ExpectedTitle,"Title Mismatch");
		       
		     
		       
		       
		       
	        
	           
			  driver.quit();
			
		}
		
	
  }


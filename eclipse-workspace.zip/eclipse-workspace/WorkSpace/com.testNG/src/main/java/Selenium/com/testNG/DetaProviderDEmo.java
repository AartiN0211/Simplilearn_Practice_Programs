package Selenium.com.testNG;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;

public class DetaProviderDEmo {
	WebDriver driver=null;
  @Test(dataProvider = "LoginMethod")
  public void Login(String S) {
	  System.out.println(S);
//	  System.setProperty("WebDriver.chrome.driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
//     driver=new ChromeDriver();
//      driver.get("https://www.facebook.com/login/");
//      driver.findElement(By.id("email")).sendKeys(UN);
//      driver.findElement(By.id("pass")).sendKeys(PASS);
      
  }

  @DataProvider
  public String[]LoginMethod()
  { String[] data=new String[]{"UN1","PASS1","UN2","PASS2"};
  return data;
  }
  }


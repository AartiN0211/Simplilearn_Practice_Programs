package Selenium.com.testNG;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class GroupingTestCase2 {
	
	@Test(groups = {"Smoke","Functional"} )
	public void test4()
	{ System.out.println("test4");
		}    
	@Test(groups = {"Sanity","Regression"} )
	public void test5()
	 
	{System.out.println("test5");
		}
     
	@Test(groups = "E2E" )
	public void test6()
	{ System.out.println("test6");
		}

}

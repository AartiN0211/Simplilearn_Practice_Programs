package Selenium.com.testNG;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class IgnoreTestcase2 {
	@Ignore
	@Test
	public void test4()
	{ System.out.println("test4");
		}
     @Ignore
	@Test
	public void test5()
	 
	{System.out.println("test5");
		}
     
     @Ignore
	@Test
	public void test6()
	{ System.out.println("test6");
		}

}

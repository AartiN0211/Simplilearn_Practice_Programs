package Selenium.com.testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class ParameterInsertion {
	  WebDriver driver=null;
	  @BeforeMethod
	   public void LaunchBrowser()  {
		  System.setProperty("WebDriver.chrome.driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
	       driver=new ChromeDriver();
	       driver.get("https://www.facebook.com/");
	  }
		@Test(priority=1)
		public void Login()
		{ 
			
		       driver.findElement(By.id("email")).sendKeys("vhhsdjs",Keys.ENTER);

		       //Title Assertion
		       String ExpectedTitle=driver.getTitle();
		       String actual= "Log in to Facebook" ; 
		       assertEquals(actual,ExpectedTitle,"Title Mismatch");
		       
		}

  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}

package Selenium.com.testNG;

import org.testng.annotations.Test;

public class Dependencies {
	
	
	@Test(priority = 2)
	public void Create()
	{   System.out.println(5/0);
		System.out.println("Create Shipment");
	}
	@Test(priority = 1, dependsOnMethods = {"Create"},alwaysRun = true)
	public void TrackShipment()
	{System.out.println(5/0);
		System.out.println("Track Shipment");
	}
	@Test(priority = 3, dependsOnMethods = {"Create"})
	public void CancelShipment()
	{
		System.out.println("Cancel Shipment");
	}

}

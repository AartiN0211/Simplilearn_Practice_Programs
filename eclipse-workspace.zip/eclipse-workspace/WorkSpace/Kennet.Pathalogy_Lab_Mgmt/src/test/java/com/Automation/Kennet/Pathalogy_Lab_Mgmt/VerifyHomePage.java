package com.Automation.Kennet.Pathalogy_Lab_Mgmt;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class VerifyHomePage extends BaseClass{

	PropertyHandlingPage prop;
	LoginPage LoginPage;
	HomePage Title;
	
	@BeforeTest
	public void GetBrowserLaunch() throws IOException
	{
		prop=new PropertyHandlingPage();
		getBrowserInstance(prop.getProperty("browser"));
		LoginPage=new LoginPage();
		driver.navigate().to(prop.getProperty("URL"));
		driver.manage().window().maximize();
	}
	 
	@Test(priority = 2)
	public void LoginPage() throws IOException
	{
		
		LoginPage.login(prop.getProperty("GOREmailID"),prop.getProperty("password"));	
	}
	
	@Test(priority = 3)
	public void DashBoardPage() throws InterruptedException
	{
		System.out.print("Verified DashBoard Title on Home Page");
		Thread.sleep(5000);
		Title=new HomePage();
		
		
		String ActualDashBoardTitle= Title.TitleOfHomePage.getText();
		String ExpectedDashBoardTitle="Dashboard";
		getAssertion(ExpectedDashBoardTitle,ActualDashBoardTitle);
		
     
	}
	@Test(priority = 4) 
	public void VerifyList() {
		List<WebElement> list=driver.findElements(By.tagName("li"));
		list.forEach(ListNames->{
			String names=ListNames.getAttribute("class");
			System.out.println(names);
		});
	}
	@Test(priority = 5) 
	public void AddPetients() throws InterruptedException {
		
		Title=new HomePage();
		Title.PatientsTab.click();
		Title.AddPatientsButton.click();
		Title.AddPatientsDetails();
	}
	
	
	/*
	 * @Test(priority = 5) public void CostCalculatorFeature() throws
	 * InterruptedException { // Thread.sleep(5000); // JavascriptExecutor js =
	 * (JavascriptExecutor) driver; // js.executeScript("windows.scrollBy(0,1000)");
	 * System.out.print("Verified CostCalculator Title"); Thread.sleep(5000);
	 * Title=new HomePage();
	 * 
	 * 
	 * String ActualCalcyName= Title.CostCalculator.getText(); String
	 * ExpectedCalcyName="Test Cost Calculator";
	 * getAssertion(ExpectedCalcyName,ActualCalcyName);
	 * 
	 * Title.AddPetientsInputField.click();
	 * 
	 * 
	 * 
	 * 
	 * }
	 */
	
	
	/*
	 * @AfterTest public void Close() { driver.quit(); }
	 */
	
	
}

package com.Automation.Kennet.Pathalogy_Lab_Mgmt;



import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.function.Function;

import org.apache.commons.lang3.math.Fraction;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.Assertion;


public class BaseClass {
       public static WebDriver driver=null;
       WebDriverWait wait;
       public static void getBrowserInstance(String Browser)
       {
    	   switch(Browser)
    	   {
    	   case "Chrome":
    		   System.setProperty("webdriver.chrome.driver","C:\\Users\\Aarti\\Downloads\\chromedriver-win64\\chromedriver.exe");
    		    driver=new ChromeDriver(); 
    		 break;   
    		 
    		    
    	   case "FireFox":
    	    		   System.setProperty("webdriver.gicko.driver", "C:\\Users\\Aarti\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
    	    		    driver=new ChromeDriver();  
    	        break;   

    	    		    
    	   case "Edge":
    		   System.setProperty("webdriver.edge.driver", "C:\\Users\\Aarti\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
    		    driver=new ChromeDriver(); 
       		 break;   

    	   }
    	   
    	   
       }
       
       public static void getAssertion(String Expected, String Actual)
       {    
    	   Assertion assertion = new Assertion();
		assertion.assertEquals(Expected,Actual);
       }

	
       }
        
         
    
        
      

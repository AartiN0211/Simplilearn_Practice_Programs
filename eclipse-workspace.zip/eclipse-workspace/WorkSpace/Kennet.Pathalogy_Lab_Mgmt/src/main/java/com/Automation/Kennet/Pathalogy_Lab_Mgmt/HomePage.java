package com.Automation.Kennet.Pathalogy_Lab_Mgmt;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;



public class HomePage extends BaseClass {
	
	public HomePage()
		 {
	    	  PageFactory.initElements(driver, this);	
	      }  
	
		 @FindBy(xpath="//div[contains(text(),'Dashboard')]")
		 public WebElement TitleOfHomePage;
		 
			
	   @FindBy(xpath="//div[starts-with(text(),'Test Cost Calculator')]") 
	   public WebElement CostCalculator;
	   
	   @FindBy(xpath="//input[@id='patient-test']")
	   public WebElement AddPetientsInputField;
	   
	   @FindBy(xpath="//span[contains(text(),'Patients')]")
	   public WebElement PatientsTab;
       
	   @FindBy(xpath="//a[@href='/patients/add']/button")
	   public WebElement AddPatientsButton;
       
	   @FindBy(xpath="//input[@name='name']")
	   public WebElement Namefield;
	   
	   @FindBy(xpath="//input[@type='email']")
	   public WebElement Emailfield;
	   
	   @FindBy(xpath="//input[@name='phone']")
	   public WebElement PhoneField;
	   
	   @FindBy(xpath="//div[@class='jss108']/button[2]")
	   public WebElement GeneralDetailsButton;
	   
	   @FindBy(xpath="//input[@name='height']")
	   public WebElement heightField;
	   
	   @FindBy(xpath="//input[@name='weight']")
	   public WebElement weightField;
	 
	   @FindBy(xpath="//div[@id='mui-component-select-gender']")
	   public WebElement GenderField;
	 
	   @FindBy(id="menu-gender")
	   public WebElement ageField;
	   
	   @FindBy(xpath="//div[@class='jss129']/button[2]/span[1]")
	   public WebElement addTestButton;
	   
public void AddPatientsDetails() throws InterruptedException
{  
	this.Namefield.sendKeys("abc");
    this.Emailfield.sendKeys("abc@gmail.com");
    this.PhoneField.sendKeys("0123456789");
    this.GeneralDetailsButton.click();
    this.heightField.sendKeys("121");
    this.weightField.sendKeys("63");
	this.GenderField.click();
    WebElement Male = driver.findElement(By.xpath("//div[@id='mui-component-select-gender']"));
    Male.click();
     
    
	//WebElement desiredOption = driver.findElement(By.xpath("//div[@id='mui-component-select-gender']"));
    //desiredOption.click();
	//Select gender = new Select(GenderField);
	//gender.selectByVisibleText("Male");
	this.ageField.sendKeys("21");
	this.addTestButton.click();
}}
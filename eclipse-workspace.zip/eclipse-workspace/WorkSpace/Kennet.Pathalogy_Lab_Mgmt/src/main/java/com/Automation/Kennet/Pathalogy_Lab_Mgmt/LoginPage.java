package com.Automation.Kennet.Pathalogy_Lab_Mgmt;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BaseClass{
      public LoginPage() 
      {
    	  PageFactory.initElements(driver, this);	
      }  
    	  @FindBy(xpath="//input[@name='email']") 
    	  public WebElement EmailID;
    	  
    	  @FindBy(xpath="//input[@name='password']") 
    	  public WebElement Password;
    	  
    	  @FindBy(xpath="//button[@type='submit']") 
    	  public WebElement LoginButton;	  
    	
      
public void login(String EmailID, String Password)
{
	this.EmailID.sendKeys("test@kennect.io");
	this.Password.sendKeys("Qwerty@1234");
	LoginButton.click();
	}
}
package com.NikhilAutomation;

class Demo1{
	boolean x=true;
}

class Demo2{
	void m1() {
		System.out.println("In class 2 non static method");
	}
}
public class StaticMethodClass1 {

	public static void main(String[] args) {
		Demo1 a=new Demo1();
		System.out.println(a.x);
		Demo2 b=new Demo2();
        b.m1();
        StaticMethodClass1 m=new StaticMethodClass1();
        m.m2();
     
	}
   void m2()
{   System.out.println("In class 3 method");
     
	   }}

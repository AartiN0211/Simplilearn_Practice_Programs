package com.NikhilAutomation;

public class Program1 {
public static WebDriver driver;
	
	@Test
	public void ReadDataFromExcel() throws EncryptedDocumentException, IOException
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();
		
		AmazonSearchPageObjects pf = new AmazonSearchPageObjects(driver);
		
		//Step 1 is to read the excel file
		
		FileInputStream fs = new FileInputStream("./TestData/InputData.xlsx");
		
		//Step 2 is to assign the file to a work book class
		
		Workbook wb = WorkbookFactory.create(fs);
		
		//Step 3 Read the work sheet inside the workbook
		
		Sheet sh = wb.getSheet("SearchData");
		
		//Step 4 is the read the row value
		
		Row rw = sh.getRow(1);
		
		//Step 5 is to define the col value
		Cell celldata = rw.getCell(0);
		
		System.out.println("The value from the excel sheet is "+celldata.getStringCellValue());
		
		String TestData = celldata.getStringCellValue();
		
		
		pf.EnterSearchTerm(TestData);
		pf.SearchIcon().click();
		
		System.out.println("To fetch all the data from cell");
		
		//normal for loop
		for(int i=1;i<=sh.getLastRowNum();i++)
		{
			Row rowvalue = sh.getRow(i);
			System.out.println(rowvalue.getCell(0));
			Cell data = rowvalue.getCell(0);
			String SearchData = data.getStringCellValue();
			pf.EnterSearchTerm(SearchData);
			pf.SearchIcon().click();
			pf.SearchTextBox().clear();
		}


		
		for(Row rowvalue:sh)
		{
			Cell searchdata = rowvalue.getCell(0);
			System.out.println(searchdata);
		}
		
	}
}


}

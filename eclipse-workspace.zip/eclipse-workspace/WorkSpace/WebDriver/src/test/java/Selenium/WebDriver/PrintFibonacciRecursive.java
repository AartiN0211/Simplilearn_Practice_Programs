package Selenium.WebDriver;

public class PrintFibonacciRecursive {
	public static void main(String [] args) {
     int length=10;
     for(int x=0;x<length;x++) {
       System.out.println(febonacciseries(x));
	}}
	private static int febonacciseries(int x2) {
	   if(x2<=1) {
		   return x2;
	   }
	}

}

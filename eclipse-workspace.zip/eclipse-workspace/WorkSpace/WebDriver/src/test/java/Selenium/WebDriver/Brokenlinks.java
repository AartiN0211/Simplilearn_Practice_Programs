package Selenium.WebDriver;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Brokenlinks {

	public static void main(String[] args) {
       System.setProperty("WebDriver.chrome.driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
       WebDriver driver=new ChromeDriver();
       driver.get("https://www.amazon.in/");
       List <WebElement> links= driver.findElements(By.tagName("a"));
       System.out.println(links);
       links.forEach((Element)->{
    	   String linkurl=Element.getAttribute("href");
    	   System.out.println(linkurl);
    	   if(Objects.nonNull(linkurl) && linkurl.startsWith("https"))
    	   {
    		   try {
				URL url=new URL(linkurl);
				URLConnection connection= url.openConnection();
				HttpURLConnection connect=(HttpURLConnection)connection;
				connect.connect();
				if(connect.getResponseCode()!=200)
				{
					System.out.println(connect.getResponseCode()+" "+url);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	   }
       });
	} 

}

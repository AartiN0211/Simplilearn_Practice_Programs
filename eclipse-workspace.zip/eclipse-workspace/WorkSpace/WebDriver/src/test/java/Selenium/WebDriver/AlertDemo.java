package Selenium.WebDriver;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertDemo {

	public static void main(String[] args) throws Exception {
		  System.setProperty("WebDriver.Chrome.Driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
		     WebDriver driver=new ChromeDriver();
		     driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
		     Thread.sleep(3000);
		     //simple Alert
//		     driver.findElement(By.id("alertBox")).click();
//		     Alert simpleAlert=driver.switchTo().alert();
//		     simpleAlert.accept();
		     
		     //Confirmation Alert
		     driver.findElement(By.xpath("//button[@id=\"confirmBox\"]")).click();
		     Thread.sleep(3000);
		     Alert cmrfAlert=driver.switchTo().alert();
		     cmrfAlert.accept();
		     System.out.println(driver.findElement(By.id("output")).getText());
		     driver.quit();
		     
		     
		     
	}

}

package Selenium.WebDriver;

public class PrimeNo {

	public static void main(String[] args) {
		int a,b,c = 1;
	    a=0;
	    b=1;
	    for(int x=0; x<10;x++)
	    {
	    	System.out.println("a = "+a);
	    	a=b; //1
	    	b=c;  //1  2
	    	c=a+b; //2  3
	    }
	    
}}

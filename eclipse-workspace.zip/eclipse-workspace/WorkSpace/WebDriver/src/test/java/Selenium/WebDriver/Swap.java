package Selenium.WebDriver;

public class Swap {

	public static void main(String[] args) {
		int a, b;
		a=200;
		b=300;
		System.out.println(a);
		System.out.println(b);

		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a);
		System.out.println(b);

	}

}

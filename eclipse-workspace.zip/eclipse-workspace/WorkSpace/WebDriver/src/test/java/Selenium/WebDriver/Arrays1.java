package Selenium.WebDriver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Arrays1 {
	
	
	public static void main(String[] args) {
		String str = "123";
       StringBuffer s=new StringBuffer();
       char [] c=str.toCharArray();
	    for(int x=c.length-1;x>=0;x--)
	    {	
	      s.append(c[x]);
	    }
		System.out.println(s.toString());
	}}
	     



package Selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.chromium.ChromiumOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
public class JavaScriptExecutor {

	public static void main(String[] args) throws Exception {
     System.setProperty("WebDriver.Chrome.Driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
    
     ChromeOptions option=new ChromeOptions();
//     option.addArguments("headless");
//     option.setHeadless(true);
     option.addArguments("--Incognito");
     WebDriver driver=new ChromeDriver(option);
     
     driver.get("https://www.amazon.in/");
     //for click operation we used javascript executor
     JavascriptExecutor  js=(JavascriptExecutor)driver;
     // js.executeScript("arguments[0].click()",driver.findElement(By.id("nav-global-location-popover-link")));
     //to handle alerts we use javascript executor
     //js.executeScript("Confirm(This is a sample alert in Selenium);", "");
      
     
     //to vertical scrolling to base
     js.executeScript("window.scrollTo(0,document.body.scrollHeight)","");
     Thread.sleep(5000);
     
     driver.quit();
     
     
     
     
     
	}

}

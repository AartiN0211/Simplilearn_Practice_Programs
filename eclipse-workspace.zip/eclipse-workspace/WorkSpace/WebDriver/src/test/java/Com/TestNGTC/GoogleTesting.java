package Com.TestNGTC;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class GoogleTesting {
	WebDriver driver=null;
	@BeforeMethod
	public void BrowserLaunch() {
		 System.setProperty("WebDriver.chrome.driver", "E:\\Aarti\\Autmation\\Driver\\chromedriver_win32\\chromedriver.exe");
	       driver=new ChromeDriver();
	       driver.get("https://www.google.in/");
	}
	
	@Test
	public void GoogleSearch()
	{
		System.out.println(driver.findElement(By.id("ctaCanvas")).isDisplayed());
	}
	
	
}

package Selenium.WebDriver;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Excel {
public static WebDriver driver;
	
	@Test
	public void ReadDataFromExcel() throws EncryptedDocumentException, IOException
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();
		
		AmazonSeachFunctionality pf = new AmazonSeachFunctionality();
		
		//Step 1 is to read the excel file
		
		FileInputStream fs = new FileInputStream("/WebDriver/TestData/Data.xlsx");
		
		//Step 2 is to assign the file to a work book class
		
		Workbook wb = WorkbookFactory.create(fs);
		
		//Step 3 Read the work sheet inside the workbook
		
		Sheet sh = wb.getSheet("SearchData");
		
		//Step 4 is the read the row value
		
		Row rw = sh.getRow(1);
		
		//Step 5 is to define the col value
		Cell celldata = rw.getCell(0);
		
		System.out.println("The value from the excel sheet is "+celldata.getStringCellValue());
		
		String TestData = celldata.getStringCellValue();
		
		
		pf.EnterSearchTerm(TestData);
		pf.SearchIcon().click();
		
		System.out.println("To fetch all the data from cell");
		
		//normal for loop
		for(int i=1;i<=sh.getLastRowNum();i++)
		{
			Row rowvalue = sh.getRow(i);
			System.out.println(rowvalue.getCell(0));
			Cell data = rowvalue.getCell(0);
			String SearchData = data.getStringCellValue();
			pf.EnterSearchTerm(SearchData);
			pf.SearchIcon().click();
			pf.SearchTextBox().clear();
		}


		
		for(Row rowvalue:sh)
		{
			Cell searchdata = rowvalue.getCell(0);
			System.out.println(searchdata);
		}
		
	}
}



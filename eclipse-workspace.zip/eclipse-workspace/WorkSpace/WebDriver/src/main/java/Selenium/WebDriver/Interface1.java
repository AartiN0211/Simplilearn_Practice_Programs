package Selenium.WebDriver;

public interface Interface1 {
	void Loans();
	void Insurance();
	void Finance();
}
abstract class Demo2 implements Interface1{
	public void Loans() {
		System.out.println("Loans");
	}
}
 abstract class Demo3 extends Demo2{
	public void Insurance() {
		System.out.println("Insurance");
	}}
class Demo4 extends Demo3{
	public void Finance() {
		System.out.println("Finance");
	}}
class Consumer{
	public static void main(String[] Args) {
		Demo4 a=new Demo4();
		a.Finance();
		a.Loans();
		a.Insurance();
	}
}

package Selenium.WebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AmazonSeachFunctionality {
public static WebDriver driver;
	
	//Technique1 where we define the locators using By keyword
	
	By SearchBox = By.xpath("//input[@id='twotabsearchtextbox']");
	By SearchIcon = By.id("nav-search-submit-button");
	
	
	public void AmazonSearchPageObjects(WebDriver driver)
	{
		//This keyword is used to denote the local object of the class
		this.driver = driver;
	}
	
	public void EnterSearchTerm(String testdata)
	{
		driver.findElement(SearchBox).sendKeys(testdata);
	}
	
	public void verifySearchbox()
	{
		driver.findElement(SearchBox).isDisplayed();
	}
	
	public WebElement SearchTextBox()
	{
		return driver.findElement(SearchBox);
	}
	
	public WebElement SearchIcon()
	{
		return driver.findElement(SearchIcon);
	}
}




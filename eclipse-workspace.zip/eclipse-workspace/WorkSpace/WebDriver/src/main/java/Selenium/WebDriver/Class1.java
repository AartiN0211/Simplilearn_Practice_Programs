package Selenium.WebDriver;

public class Class1 {

	public static void main(String[] args) {
      System.out.println("Hello");
	}

}
